CREATE DATABASE  IF NOT EXISTS `project_nowcoder` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `project_nowcoder`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: project_nowcoder
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '唯一id，标识符',
  `username` varchar(50) DEFAULT NULL COMMENT '用户名',
  `password` varchar(50) DEFAULT NULL COMMENT '用户密码',
  `salt` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL COMMENT '用户注册邮箱',
  `type` int DEFAULT NULL COMMENT '0-普通用户; 1-超级管理员; 2-版主;',
  `status` int DEFAULT NULL COMMENT '0-未激活; 1-已激活 2-账户被禁用;',
  `activation_code` varchar(100) DEFAULT NULL COMMENT '激活码',
  `header_url` varchar(200) DEFAULT NULL COMMENT '用户头像地址',
  `create_time` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `creator` varchar(45) DEFAULT NULL COMMENT '创建人',
  `update_time` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  `updater` varchar(45) DEFAULT NULL COMMENT '修改人',
  PRIMARY KEY (`id`),
  KEY `index_username` (`username`(20)),
  KEY `index_email` (`email`(20))
) ENGINE=InnoDB AUTO_INCREMENT=153 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'SYSTEM','SYSTEM','SYSTEM','nowcoder1@sina.com',0,1,NULL,'http://static.nowcoder.com/images/head/notify.png','2019-04-13 02:11:03',NULL,NULL,NULL),(11,'nowcoder11','25ac0a2e8bd0f28928de3c56149283d6','49f10','nowcoder11@sina.com',1,1,NULL,'http://images.nowcoder.com/head/11t.png','2019-04-17 09:11:27',NULL,NULL,NULL),(12,'nowcoder12','25ac0a2e8bd0f28928de3c56149283d6','49f10','nowcoder12@sina.com',1,1,NULL,'http://images.nowcoder.com/head/12t.png','2019-04-17 09:11:28',NULL,NULL,NULL),(13,'nowcoder13','25ac0a2e8bd0f28928de3c56149283d6','49f10','nowcoder13@sina.com',1,1,NULL,'http://images.nowcoder.com/head/13t.png','2019-04-17 09:11:28',NULL,NULL,NULL),(21,'nowcoder21','25ac0a2e8bd0f28928de3c56149283d6','49f10','nowcoder21@sina.com',2,1,NULL,'http://images.nowcoder.com/head/21t.png','2019-04-17 09:11:28',NULL,NULL,NULL),(22,'nowcoder22','25ac0a2e8bd0f28928de3c56149283d6','49f10','nowcoder22@sina.com',2,1,NULL,'http://images.nowcoder.com/head/22t.png','2019-04-17 09:11:28',NULL,NULL,NULL),(23,'nowcoder23','25ac0a2e8bd0f28928de3c56149283d6','49f10','nowcoder23@sina.com',2,1,NULL,'http://images.nowcoder.com/head/23t.png','2019-04-17 09:11:28',NULL,NULL,NULL),(24,'nowcoder24','25ac0a2e8bd0f28928de3c56149283d6','49f10','nowcoder24@sina.com',2,1,NULL,'http://images.nowcoder.com/head/24t.png','2019-04-17 09:11:28',NULL,NULL,NULL),(25,'nowcoder25','25ac0a2e8bd0f28928de3c56149283d6','49f10','nowcoder25@sina.com',2,1,NULL,'http://images.nowcoder.com/head/25t.png','2019-04-17 09:11:28',NULL,NULL,NULL),(101,'liubei','390ba5f6b5f18dd4c63d7cda170a0c74','12345','nowcoder101@sina.com',0,1,NULL,'http://images.nowcoder.com/head/100t.png','2019-04-03 04:04:55',NULL,NULL,NULL),(102,'guanyu','390ba5f6b5f18dd4c63d7cda170a0c74','12345','nowcoder102@sina.com',0,1,NULL,'http://images.nowcoder.com/head/200t.png','2019-04-03 04:04:55',NULL,NULL,NULL),(103,'zhangfei','390ba5f6b5f18dd4c63d7cda170a0c74','12345','nowcoder103@sina.com',0,1,NULL,'http://images.nowcoder.com/head/100t.png','2019-04-03 04:04:55',NULL,NULL,NULL),(111,'aaa','b8ca3cbc6fd57c78736c66611a7e7044','167f9','nowcoder111@sina.com',0,1,NULL,'http://images.nowcoder.com/head/111t.png','2019-04-03 07:31:19',NULL,NULL,NULL),(112,'bbb','216dc48902665b6a6dba534717d49592','90ad0','nowcoder112@sina.com',0,1,NULL,'http://images.nowcoder.com/head/112t.png','2019-04-04 10:36:24',NULL,NULL,NULL),(113,'ccc','511247cf6bf9cf3d37aef555d0dd9b75','fe290','nowcoder113@sina.com',0,1,NULL,'http://images.nowcoder.com/head/705t.png','2019-04-06 13:29:52',NULL,NULL,NULL),(114,'ddd','d432b1aaec9197cb6e23ed8e335fe42f','fd1b1','nowcoder114@sina.com',0,1,NULL,'http://images.nowcoder.com/head/972t.png','2019-04-06 13:30:36',NULL,NULL,NULL),(115,'eee','caca1fe634005d505afd82ef7874fc4f','0c8d2','nowcoder115@sina.com',0,1,NULL,'http://images.nowcoder.com/head/316t.png','2019-04-06 13:30:48',NULL,NULL,NULL),(116,'fff','deda51913a3ae16d9915fc4c520ac4b6','19341','nowcoder116@sina.com',0,1,NULL,'http://images.nowcoder.com/head/180t.png','2019-04-06 13:31:00',NULL,NULL,NULL),(117,'ggg','4e85bff4afbb34b2dd676f5e5737050f','9931d','nowcoder117@sina.com',0,1,NULL,'http://images.nowcoder.com/head/896t.png','2019-04-06 13:31:19',NULL,NULL,NULL),(118,'hhh','8d4c0d490ea1585cd7973bb55bd39d07','e123d','nowcoder118@sina.com',0,1,NULL,'http://images.nowcoder.com/head/834t.png','2019-04-06 13:38:18',NULL,NULL,NULL),(119,'iii','2214de584a27c7c28dd46a9505bfdc8b','f8880','nowcoder119@sina.com',0,1,NULL,'http://images.nowcoder.com/head/240t.png','2019-04-06 13:38:33',NULL,NULL,NULL),(120,'jjj','9522866891d647323a7fb5c640b8fa37','12c25','nowcoder120@sina.com',0,1,NULL,'http://images.nowcoder.com/head/760t.png','2019-04-06 13:39:45',NULL,NULL,NULL),(121,'kkk','5a80e7d897dec9b0aec2919fb42a158e','b8710','nowcoder121@sina.com',0,1,NULL,'http://images.nowcoder.com/head/358t.png','2019-04-06 13:41:34',NULL,NULL,NULL),(122,'lll','fdc3616df634614bc0ffacee17f735bd','b067f','nowcoder122@sina.com',0,1,NULL,'http://images.nowcoder.com/head/70t.png','2019-04-06 13:45:36',NULL,NULL,NULL),(123,'mmm','d9b57ddfa9faa06c581c803dc2811edb','f7014','nowcoder123@sina.com',0,1,NULL,'http://images.nowcoder.com/head/160t.png','2019-04-06 13:48:34',NULL,NULL,NULL),(124,'nnn','f878b7181a95a3330d90198deab16aca','bbf47','nowcoder124@sina.com',0,1,NULL,'http://images.nowcoder.com/head/506t.png','2019-04-06 13:49:39',NULL,NULL,NULL),(125,'ooo','f71e07cc9c6ebb9e8cfc1fc58265ff33','ff72a','nowcoder125@sina.com',0,1,NULL,'http://images.nowcoder.com/head/45t.png','2019-04-06 13:50:35',NULL,NULL,NULL),(126,'ppp','e2f178c5076dabbb35b73da19774b271','5027b','nowcoder126.sina.com',0,1,NULL,'http://images.nowcoder.com/head/771t.png','2019-04-06 13:51:42',NULL,NULL,NULL),(127,'qqq','d209b28b19fdcb4aafc3a795157a4651','3aebf','nowcoder127@sina.com',0,1,NULL,'http://images.nowcoder.com/head/492t.png','2019-04-06 13:52:29',NULL,NULL,NULL),(128,'rrr','a6043995e741593540687d87c1ce40e8','c543c','nowcoder128@sina.com',0,1,NULL,'http://images.nowcoder.com/head/779t.png','2019-04-06 13:53:19',NULL,NULL,NULL),(129,'sss','ae8754f0d791f9fea1627a1862c4de5f','d3641','nowcoder129@sina.com',0,1,NULL,'http://images.nowcoder.com/head/977t.png','2019-04-06 13:57:34',NULL,NULL,NULL),(131,'ttt','d50960f067142c59cc3bdac61b87759f','72450','nowcoder131@sina.com',0,1,NULL,'http://images.nowcoder.com/head/677t.png','2019-04-08 04:05:49',NULL,NULL,NULL),(132,'uuu','a80ba77157d2fd9c67dd3187907cef42','f1113','nowcoder132@sina.com',0,1,NULL,'http://images.nowcoder.com/head/278t.png','2019-04-08 06:07:04',NULL,NULL,NULL),(133,'vvv','252c226ba0a601ec3fa4d7c58b2291d9','13211','nowcoder133@sina.com',0,1,NULL,'http://images.nowcoder.com/head/133t.png','2019-04-19 03:08:55',NULL,NULL,NULL),(134,'www','3d3aeebb9cd302ae581dfa8fedd86ceb','dfc00','nowcoder134@sina.com',0,1,NULL,'http://images.nowcoder.com/head/134t.png','2019-04-19 10:13:57',NULL,NULL,NULL),(137,'xxx','046291c11cdfb896aa7cd48714bb6352','968fc','nowcoder137@sina.com',0,1,NULL,'http://images.nowcoder.com/head/677t.png','2019-04-26 11:48:31',NULL,NULL,NULL),(138,'yyy','046291c11cdfb896aa7cd48714bb6352','968fc','nowcoder138@sina.com',0,1,'69dcd69f4c0145058df820e90820ba1e','http://images.nowcoder.com/head/138t.png','2019-04-25 07:18:07',NULL,NULL,NULL),(144,'zzz','07b83b7747ca08bc4b0153d5b8ce7519','21e8b','nowcoder144@sina.com',0,1,'107eb2cbb8454fbe96848790e6a730b1','http://images.nowcoder.com/head/144t.png','2019-04-26 08:59:50',NULL,NULL,NULL),(145,'lhh','d980a16ea0b3c8a81062ee806e65a4bc','5abfc','nowcoder145@sina.com',0,1,'f217b637e9544e2a9b4a88f78c583d03','http://images.nowcoder.com/head/145t.png','2019-04-28 07:30:36',NULL,NULL,NULL),(146,'lihonghe','100489ece9bacfa4d57eb5777b4d4643','00d7a','nowcoder146@sina.com',0,1,'5a61faee7af94e89ba7237b1277c9fed','http://images.nowcoder.com/head/146t.png','2019-04-29 03:47:24',NULL,NULL,NULL),(149,'niuke','ebce124c4ba2de3be92dc9a3bc1ea75b','90196','nowcoder149@sina.com',0,1,'d7a5714a145b4461b5a4199cc5a0014f','http://images.nowcoder.com/head/149t.png','2019-05-17 07:48:11',NULL,NULL,NULL),(150,'F1336301','0d4a1e8caea05b0737f68bb50ec0fd64','fh9fk5','F1336301@qq.com',0,1,'f1f06f0da7594774b3c3d706aa4af865','http://images.nowcoder.com/head/32t.png','2023-03-13 10:20:14','system','2023-03-15 07:45:07','F1336301'),(151,'F1336302','9b81f288b6c1005457a92d09b9efa1b6','f30llg','11111@qq.com',0,0,'a0273109a57e4d41835c3572a138d88b','http://images.nowcoder.com/head/80t.png','2023-03-13 11:25:35','system','2023-03-13 11:25:35','system'),(152,'F1336303','211c30bc120ce926704fc3e17550d9a7','1k3bk8','ddfd@qq.com',0,1,'0ef06040f186484cbd6fbb555012bf7d','http://images.nowcoder.com/head/37t.png','2023-03-13 11:29:09','system','2023-03-13 11:29:09','system');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-16 11:56:51
