package com.nowcoder.community;


import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;


/**
 * @Author lyf
 * @Date 2023/3/9 - 14:08
 * @Description
 **/
@SpringBootTest
@ContextConfiguration(classes = CommunityApplication.class)
public class LoggerTest {

    private static final Logger logger= LoggerFactory.getLogger(LoggerTest.class);

    @Test
    public void logInfo(){
        System.out.println(logger.getName());
        logger.info("hello message");
        logger.trace("hello message");
        logger.warn("hello message");
        logger.error("hello message");
    }
}
