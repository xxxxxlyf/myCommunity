package com.nowcoder.community;

import com.nowcoder.community.util.CommunityUtil;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @Author lyf
 * @Date 2023/3/13 - 16:19
 * @Description
 **/
@SpringBootTest
@ContextConfiguration(classes = CommunityApplication.class)
public class UtilTest {


    @Test
    public void test(){
        System.out.println(CommunityUtil.randomStr(6));
    }

    @Test
    public void test1(){
        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        //
        Date date=new Date(System.currentTimeMillis()+60*60*24*30L*1000);
        String format1 = format.format(date);
        System.out.println(format1);
    }
}
