package com.nowcoder.community;

import com.nowcoder.community.entity.MailBody;
import com.nowcoder.community.util.MailUtil;
import net.bytebuddy.asm.Advice;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import java.util.HashMap;

/**
 * @Author lyf
 * @Date 2023/3/13 - 09:18
 * @Description
 **/
@SpringBootTest
@ContextConfiguration(classes = CommunityApplication.class)
public class MailTest {


    @Autowired
    private MailUtil mailUtil;

    @Value("${spring.mail.username}")
    private String mailFrom;

    @Autowired
    private TemplateEngine engine;

    @Test
    public void test(){

        MailBody body=new MailBody();
        body.setCC(false);
        body.setMailTo("1779178166@qq.com");
        body.setMailContent("hello word");
        body.setMailSubject("测试邮件内容发送");
        body.setMailFrom(mailFrom);
        mailUtil.sendMail(body);
    }

    @Test
    public void test1(){

        MailBody body=new MailBody();
        body.setCC(false);
        body.setMailTo("1779178166@qq.com");
        Context context=new Context();
        HashMap<String,Object>variables=new HashMap<>();
        variables.put("username","lyf");
        variables.put("activation_url","http://localhost:8080/comunity/login/activation");
        context.setVariables(variables);
        String content=engine.process("/mail/activation",context);
        body.setMailContent(content);
        body.setMailSubject("测试邮件内容发送");
        body.setMailFrom(mailFrom);
        mailUtil.sendMail(body);
    }
}
