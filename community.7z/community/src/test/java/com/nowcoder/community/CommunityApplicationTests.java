package com.nowcoder.community;



import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.nowcoder.community.dao.DiscussPostMapper;
import com.nowcoder.community.dao.UserMapper;
import com.nowcoder.community.entity.DiscussPost;
import com.nowcoder.community.entity.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

import java.util.List;


@SpringBootTest
@ContextConfiguration(classes = CommunityApplication.class)
public class CommunityApplicationTests  {


	@Autowired
	private UserMapper mapper;

	@Autowired
	private DiscussPostMapper discussPostMapper;

	@Test
	public void test(){
		List<User> users = mapper.selectList(new QueryWrapper<User>()
				.eq("username", "liubei")
				.eq("password", "390ba5f6b5f18dd4c63d7cda170a0c74"));
		User user=mapper.selectUser("liubei","390ba5f6b5f18dd4c63d7cda170a0c74");

		User user1=new User();
		user1.setUsername("lyf");
		user1.setUsername("Foxconnlyf123");
		user1.setEmail("it-api@mail.foxconn.com");
		user1.setSalt("salt");

	}

	@Test
	public void demo2(){
		System.out.println(discussPostMapper.selectPostCount(0));
		List<DiscussPost> discussPosts = discussPostMapper.selectPostsByPage(0, 0, 10);
		for (int i = 0; i < discussPosts.size(); i++) {
			System.out.println(discussPosts.get(i).getTitle());
		}


	}

}
