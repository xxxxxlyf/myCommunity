package com.nowcoder.community.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.nowcoder.community.entity.User;
import org.springframework.stereotype.Repository;


@Repository
public interface UserMapper extends BaseMapper<User> {

    User selectUser(String username,String password);

    /**
     * 根据用户id查询用户信息
     * @param userId
     * @return
     */
    User selectUserById(int userId);

    /**
     * 修改用户状态
     * @param id
     * @param status
     * @return
     */
    int updateStatus(int id,int status);

}
