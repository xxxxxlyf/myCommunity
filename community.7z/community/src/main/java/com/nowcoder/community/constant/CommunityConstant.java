package com.nowcoder.community.constant;

public interface CommunityConstant {

    /**
     * 成功激活
     */
    int ACTIVATION_SUCCESS=0;
    /**
     * 重复激活
     */
    int ACTIVATION_REPEAT=1;
    /**
     * 激活失败
     */
    int ACTIVATION_FAILED=2;
    /**
     * 默认登录过期的时间是12H
     */
    int DEFAULT_EXPIRED_SECONDS=60*60*12;
    /**
     * 记住我下的登录超时时间为30Day
     */
    int REMEMBER_EXPIRED_SECONDS=60*60*24*30;
    /**
     * 验证码过期时间为5MIN
     */
    int VERIFY_CODE_EXPIRED_SECONDS=60*5;
}
