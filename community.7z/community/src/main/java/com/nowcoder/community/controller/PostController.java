package com.nowcoder.community.controller;

import com.nowcoder.community.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;


import java.util.Map;

/**
 * @Author lyf
 * @Date 2023/3/2 - 10:40
 * @Description
 **/
@Controller
public class PostController {

    @Autowired
    private PostService postService;

    /**
     * 访问Index 首页
     * @return
     */
    @GetMapping("/getIndex")
    public String getIndex(Model model){
        return getPagePost(1,model);
    }


    /**
     * 当前页码
     * @param current
     * @return
     */
    @GetMapping("/page")
    public String getPagePost(int current,Model model){
        Map<String, Object> obj = postService.selectPostByPage(current, 10);
        model.addAllAttributes(obj);
        //将数据显示到帖子查询页面
        return "index";
    }
}
