package com.nowcoder.community.service;

import com.nowcoder.community.entity.LoginParam;
import com.nowcoder.community.entity.User;


import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Map;

/**
 * @Author lyf
 * @Date 2023/3/13 - 11:00
 * @Description
 **/
public interface RegisterAndLoginService {
    /**
     * 注册用户
     * @param user
     * @return
     */
    Map<String,Object> registerUser(User user);

    /**
     * 激活账号
     * @param id
     * @param activationCode
     * @return
     */
    int activationUser(int id,String activationCode);

    /**
     * 生成验证码
     * @param response
     * @param session
     */
    void generateCode(HttpServletResponse response, HttpSession session);

    /**
     * 用户登录
     * @param loginParam 登录参数类
     * @return
     */
    Map<String,String> loginUser(LoginParam loginParam);

    /**
     * 向邮件地址推送验证码邮件
     * @param mail
     * @return
     */
    Map<String,String> sendCodeEmail(String mail);

}
