package com.nowcoder.community.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.util.Date;

/**
 * @Author lyf
 * @Date 2023/3/15 - 09:37
 * @Description 验证码模型类
 **/
@Data
public class VerifyCode {

    /**
     * 唯一标识符
     */
    @TableId(type=IdType.AUTO)
    private int id;
    /**
     *推送验证码的邮箱
     */
    private String email;
    /**
     *验证码
     */
    private String code;
    /**
     * 发送验证码的业务类型
     */
    private String type;
    /**
     * 验证码发送时间
     */
    private Date sendTime;
    /**
     * 验证码过期时间
     */
    private Date expiredTime;
}
