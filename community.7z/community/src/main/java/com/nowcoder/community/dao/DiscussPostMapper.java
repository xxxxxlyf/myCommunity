package com.nowcoder.community.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.nowcoder.community.entity.DiscussPost;
import org.springframework.stereotype.Repository;
import java.util.List;

/**
 * @Author lyf
 * @Date 2023/3/3 - 09:18
 * @Description
 **/
@Repository
public interface DiscussPostMapper extends BaseMapper<DiscussPost> {


    /**
     * 查询用户发布的所有帖子信息
     * @param userId
     * @param offset
     * @param limit
     * @return
     */
    List<DiscussPost>selectPostsByPage(int userId,int offset,int limit);

    /**
     * 查询用户分页帖的总数
     * @param userId
     * @return
     */
    int selectPostCount(Integer userId);
}
