package com.nowcoder.community.controller;

import com.nowcoder.community.constant.CommunityConstant;
import com.nowcoder.community.entity.LoginParam;
import com.nowcoder.community.entity.User;
import com.nowcoder.community.service.RegisterAndLoginService;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author lyf
 * @Date 2023/3/1 - 16:46
 * @Description 用户注册与登录controller
 **/
@Controller
public class RegisterAndLoginController implements CommunityConstant {


    @Autowired
    private RegisterAndLoginService service;

    /**
     * 跳转到register页面
     *
     * @return
     */
    @GetMapping("/register")
    public String registerPage() {
        return "/site/register";
    }

    /**
     * 跳转到登录页面
     * @return
     */
    @GetMapping("/login")
    public String loginPage() {
        return "/site/login";
    }

    /**
     * 跳转到重设密码的页面
     * @return
     */
    @GetMapping("resetPassword")
    public String resetPage(){
        return "/site/forget";
    }

    /**
     * 用户登录
     * @param user
     * @param model
     * @return
     */
    @PostMapping("/register")
    public String register(User user, Model model) {
        Map<String, Object> returnMap = service.registerUser(user);
        //用户登录成功
        if (returnMap.isEmpty()) {
            //提示消息
            model.addAttribute("msg", "您已成功注册账号，已向您的邮箱发送了激活邮件，请尽快激活邮件");
            //需要跳转的页面
            model.addAttribute("target", "/getIndex");
            //跳转到中转页面
            return "/site/operate-result";
        } else {
            model.addAllAttributes(returnMap);
            //重新转发资源到用户注册页面
            return "/site/register";
        }
    }

    /**
     * 激活用户
     * @param id
     * @param activationCode
     * @param model
     * @return
     */
    @GetMapping("/activation/{id}/{activationCode}")
    public String activationUser(@PathVariable("id") int id, @PathVariable("activationCode") String activationCode, Model model) {
        int i = service.activationUser(id, activationCode);
        if (i == ACTIVATION_SUCCESS) {
            //提示消息
            model.addAttribute("msg", "您的账号已激活，现可正常使用了");
            //需要跳转的页面
            model.addAttribute("target", "/login");
        } else if (i == ACTIVATION_REPEAT) {
            //提示消息
            model.addAttribute("msg", "不可重复激活！");
            //需要跳转的页面
            model.addAttribute("target", "/getIndex");
        } else if (i == ACTIVATION_FAILED) {
            //提示消息
            model.addAttribute("msg", "激活失败，您提供的激活码错误");
            //需要跳转的页面
            model.addAttribute("target", "/getIndex");
        }
        //跳转到中转页面
        return "/site/operate-result";
    }

    /**
     * 生成验证码图片
     * 向response中输出code码的照片【response中写入图片流的数据】
     * 使用session技术，为了保证数据的安全，缺点会增加服务器端内存的压力
     *
     * @return
     */
    @GetMapping("/generateCode")
    public void generateCode(HttpServletResponse response, HttpSession session) {
        service.generateCode(response, session);
    }

    /**
     * 用户登录
     * @param response
     * @param request
     * @param model
     * @param session
     * @param param
     * @return
     */
    @PostMapping("/login")
    public String login(HttpServletResponse response, HttpServletRequest request, Model model, HttpSession session, LoginParam param) {
        Map<String, String> map = new HashMap<>();
        //校验验证码
        String code = (String) session.getAttribute("code");
        if(code.isEmpty()||param.getCode().isEmpty()||!code.equalsIgnoreCase(param.getCode())){
            model.addAttribute("codeMsg","验证码错误");
            return "/site/login";
        }
        map= service.loginUser(param);
        if (map.containsKey("ticket")) {
            //向客户端发送登录凭证的cookie信息
            Cookie cookie=new Cookie("ticket",map.get("ticket").toString());
            //cookie的有效路径
            cookie.setPath(request.getContextPath());
            //cookie的有效时间
            cookie.setMaxAge(param.isRememberMe()?REMEMBER_EXPIRED_SECONDS:DEFAULT_EXPIRED_SECONDS);
            response.addCookie(cookie);
            //重定向到用户首页
            return "redirect:/getIndex";
        } else {
            model.addAllAttributes(map);
            return "/site/login";
        }
    }

    /**
     * 获得验证码
     * @param email
     * @param model
     * @return
     */
    @GetMapping("/getVerifyCode/{email}")
    public String getVerifyCode(@PathVariable("email") String email,Model model){
        Map<String, String> map = service.sendCodeEmail(email);
        if(!map.isEmpty()){
            model.addAllAttributes(map);
            return "site/forget";
        }else{
            return "site/forget";
        }
    }




}
