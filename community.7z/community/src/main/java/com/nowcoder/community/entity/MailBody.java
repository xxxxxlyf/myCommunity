package com.nowcoder.community.entity;

import lombok.Data;

import java.io.InputStream;

/**
 * @Author lyf
 * @Date 2023/3/13 - 09:05
 * @Description 邮件模型类
 **/
@Data
public class MailBody {

    /**
     * 邮件发送方
     */
    private String mailFrom;
    /**
     * 邮件收件方
     */
    private String mailTo;
    /**
     * 邮件主旨
     */
    private String mailSubject;
    /**
     * 邮件内容
     */
    private String mailContent;
    /**
     * 邮件cc
     */
    private String mailCC;
    /**
     * 是否cc,默认是不推送cc的
     */
    private boolean isCC=false;
    /**
     * 是否添加附件
     */
    private boolean attachment=false;
    /**
     * 附件
     */
    private InputStream attachmentFile;
}
