package com.nowcoder.community.controller;

import com.nowcoder.community.entity.ResetPasswordParam;
import com.nowcoder.community.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Map;

/**
 * @Author lyf
 * @Date 2023/3/15 - 09:19
 * @Description 用户层
 **/
@Controller
public class UserController {

    @Autowired
    private UserService service;

    @PostMapping("/resetPassword")
    public String resetPassword(Model model, ResetPasswordParam param){
        Map<String, String> map = service.resetPassword(param);
        if(map.isEmpty()){
            model.addAttribute("msg","密码已重新设置，请登录");
            model.addAttribute("target","/login");
            //返回中转结果页面
            return "site/operate-result";
        }else{
            model.addAllAttributes(map);
            return "site/forget";
        }

    }


    /**
     * 用户登出
     * @param ticket cookie中的ticket 凭证
     * @return
     */
    @GetMapping("/logout")
    public String logout(@CookieValue("ticket") String ticket){
         service.logout(ticket);
         //重定向到登录界面
         return "redirect:/login";

    }
}
