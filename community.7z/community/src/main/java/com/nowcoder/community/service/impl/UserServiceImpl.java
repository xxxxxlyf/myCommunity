package com.nowcoder.community.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.nowcoder.community.dao.LoginTicketMapper;
import com.nowcoder.community.dao.UserMapper;
import com.nowcoder.community.dao.VerifyCodeMapper;
import com.nowcoder.community.entity.LoginTicket;
import com.nowcoder.community.entity.ResetPasswordParam;
import com.nowcoder.community.entity.User;
import com.nowcoder.community.entity.VerifyCode;
import com.nowcoder.community.service.UserService;
import com.nowcoder.community.util.CommunityUtil;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thymeleaf.expression.Strings;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author lyf
 * @Date 2023/3/4 - 16:23
 * @Description
 **/
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {


    @Autowired
    private VerifyCodeMapper mapper;

    @Autowired
    private LoginTicketMapper loginTicketMapper;

    @Override
    public Map<String, String> resetPassword(ResetPasswordParam param) {
        Map<String,String>map=new HashMap<>();
        User user=this.baseMapper.selectOne(new QueryWrapper<User>().eq("email",param.getEmail()).ne("status",2));
        if(user==null){
            map.put("userMsg","邮箱错误，请重新输入");
        }else{
            //校验验证码是否正确[只比较最近时间发送的一个验证码信息]
            VerifyCode verifyCode = mapper.selectOne(new QueryWrapper<VerifyCode>().eq("email", param.getEmail()).orderByDesc("send_time"));
            if(verifyCode==null|| StringUtils.isEmpty(verifyCode.getCode())||StringUtils.isEmpty(param.getCode())){
                map.put("codeMsg","输入的验证码错误！");
                return map;
            }
            if(verifyCode.getCode().equals(param.getCode())){
                //重新设置的密码
                String password= CommunityUtil.MD5str(user.getSalt()+param.getPassword());
                user.setPassword(password);
                user.setUpdater(user.getUsername());
                user.setUpdateTime(new Date());
                this.baseMapper.updateById(user);
            }

        }
        return map;
    }

    @Override
    public void logout(String ticket) {
        LoginTicket loginTicket=new LoginTicket();
        //设置登录凭证状态码为过期状态
        loginTicket.setStatus(1);
        UpdateWrapper<LoginTicket>wrapper=new UpdateWrapper<>();
        wrapper.eq("ticket",ticket);
        loginTicketMapper.update(loginTicket,wrapper);
    }
}
