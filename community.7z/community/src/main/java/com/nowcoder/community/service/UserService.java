package com.nowcoder.community.service;


import com.nowcoder.community.entity.ResetPasswordParam;

import java.util.Map;

/**
 * @Author lyf
 * @Date 2023/3/3 - 15:02
 * @Description
 **/
public interface UserService  {

    Map<String,String>resetPassword(ResetPasswordParam param);

    void logout(String ticket);
}
