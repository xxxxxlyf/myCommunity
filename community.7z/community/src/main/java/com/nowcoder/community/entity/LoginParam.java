package com.nowcoder.community.entity;

import lombok.Data;

/**
 * @Author lyf
 * @Date 2023/3/14 - 11:10
 * @Description 登录参数类
 **/
@Data
public class LoginParam {

    /**
     * 用户名
     */
    private String username;
    /**
     * 密码
     */
    private String password;
    /**
     * 验证码
     */
    private String code;
    /**
     * 记住我，默认为false 不记住账号信息
     */
    private boolean  rememberMe=false;
}
