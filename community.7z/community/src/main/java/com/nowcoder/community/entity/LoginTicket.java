package com.nowcoder.community.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.util.Date;

/**
 * @Author lyf
 * @Date 2023/3/14 - 11:04
 * @Description 用户登录验证
 **/
@Data
public class LoginTicket {

    /**
     * id
     */
    @TableId(type= IdType.AUTO)
    private Integer id;
    /**
     * 用户id
     */
    private Integer userId;
    /**
     * 登录凭证字符串
     */
    private String ticket;
    /**
     * 状态
     */
    private int status;
    /**
     * 过期时间
     */
    private Date expired;
    /**
     * 创建时间
     */
    private Date createTime;
}
