package com.nowcoder.community.util;

import com.nowcoder.community.entity.MailBody;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

/**
 * @Author lyf
 * @Date 2023/3/13 - 08:54
 * @Description 邮件工具类
 **/
@Component
public class MailUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(MailUtil.class);

    @Autowired
    private JavaMailSender sender;

    /**
     * 根据邮件主体推送邮件
     * @param mailBody
     */
    public void sendMail(MailBody mailBody) {
        MimeMessage message = sender.createMimeMessage();
        //使用MimeMessageHelper工具类去构建MimeMessage邮件主体
        MimeMessageHelper helper = new MimeMessageHelper(message);
        try {
            helper.setFrom(mailBody.getMailFrom());
            helper.setTo(mailBody.getMailTo());
            helper.setSubject(mailBody.getMailSubject());
            //推送cc
            if (mailBody.isCC()) {
                //使用断言判断cc不为空
                Assert.notNull(mailBody.getMailCC(), "CC address must not be null");
                helper.setCc(mailBody.getMailCC());
            }
            //默认发送的是html格式的邮件主旨内容
            helper.setText(mailBody.getMailContent(), true);
            //调用工具类发送邮件
            sender.send(helper.getMimeMessage());
            LOGGER.info("邮件推送成功");
        } catch (MessagingException e) {
            //记录异常日志
            LOGGER.error("邮件推送失败", e.getStackTrace());
        }
    }

}
