package com.nowcoder.community.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.google.code.kaptcha.Producer;
import com.nowcoder.community.constant.CommunityConstant;
import com.nowcoder.community.dao.LoginTicketMapper;
import com.nowcoder.community.dao.UserMapper;
import com.nowcoder.community.dao.VerifyCodeMapper;
import com.nowcoder.community.entity.*;
import com.nowcoder.community.service.RegisterAndLoginService;
import com.nowcoder.community.util.CommunityUtil;
import com.nowcoder.community.util.MailUtil;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import javax.imageio.ImageIO;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.*;

/**
 * @Author lyf
 * @Date 2023/3/13 - 11:05
 * @Description
 **/
@Service
public class RegisterAndLoginServiceImpl implements RegisterAndLoginService, CommunityConstant {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private LoginTicketMapper ticketMapper;

    @Autowired
    private VerifyCodeMapper verifyCodeMapper;

    @Autowired
    private MailUtil mailUtil;

    @Value("${spring.mail.username}")
    private String mailFrom;

    @Autowired
    private TemplateEngine engine;

    @Autowired
    private Producer producer;

    @Override
    public Map<String, Object> registerUser(User user) {
        Map<String, Object> returnMap = new HashMap<>();
        if (StringUtils.isEmpty(user.getUsername())) {
            returnMap.put("userMsg", "用户名不为空");
        }

        if (StringUtils.isEmpty(user.getPassword())) {
            returnMap.put("passwordMsg", "密码不为空");
        }
        if (StringUtils.isEmpty(user.getEmail())) {
            returnMap.put("emailMsg", "邮箱不为空");
        }

        //判断邮箱或用户名是否已被注册
        QueryWrapper<User> mapper = new QueryWrapper<>();
        //select count(id) from  user where status!=2 and username='XXX';
        mapper.ne("status", 2).eq("username", user.getUsername());
        Integer qty = userMapper.selectCount(mapper);
        if (qty > 0) {
            returnMap.put("userMsg", "该账号已注册，请重设用户名");
        }

        mapper.clear();
        //select count(id) from  user where status!=2 and email='XXX';
        mapper.ne("status", 2).eq("email", user.getEmail());
        qty = userMapper.selectCount(mapper);
        if (qty > 0) {
            returnMap.put("emailMsg", "该邮箱已注册，请重设邮箱");
        }

        //判断是否为空
        if (returnMap.isEmpty()) {
            //1插入用户信息
            user.setSalt(CommunityUtil.randomStr(6)); //盐
            user.setPassword(CommunityUtil.MD5str(user.getSalt() + user.getPassword())); //密码加密
            user.setActivationCode(CommunityUtil.generateUUID()); //设置激活码
            user.setType(0); //用户类型
            user.setStatus(0); //用户未激活状态
            user.setHeaderUrl(String.format("http://images.nowcoder.com/head/%dt.png",new Random().nextInt(100)));//默认头像
            user.setCreateTime(new Date()); //创建时间-系统时间
            user.setCreator("system"); //创建人
            user.setUpdater("system"); //修改时间
            user.setUpdateTime(new Date()); //修改时间-系统时间
            userMapper.insert(user); //插入数据库
            //2推送激活邮件信息
            MailBody mailBody = new MailBody();
            mailBody.setMailFrom(mailFrom);
            mailBody.setMailTo(user.getEmail());
            mailBody.setMailSubject("牛客网账号激活通知邮件");
            //2.1构建html的邮件内容
            Context context = new Context();
            context.setVariable("username", user.getUsername());
            context.setVariable("activation_url", "http://localhost:8080/community/activation/"+user.getId()+"/"+user.getActivationCode());
            String content = engine.process("/mail/activation", context);
            mailBody.setMailContent(content);
            //2.2调用工具类推送邮件信息
            mailUtil.sendMail(mailBody);

        }
        return returnMap;
    }

    @Override
    public int activationUser(int id, String activationCode) {
        //根据id查询用户信息
        User user=userMapper.selectUserById(id);
        //判断用户状态
        if(user.getStatus()==1){
            //成功激活
            return ACTIVATION_REPEAT;
        }else if(user.getActivationCode().equals(activationCode)){
            //修改用户状态
            userMapper.updateStatus(id,1);
            return ACTIVATION_SUCCESS;
        }else{
            //激活失败
            return ACTIVATION_FAILED;
        }

    }

    /**
     * 生成验证码
     * @param response
     * @param session
     */
    @Override
    public void generateCode(HttpServletResponse response, HttpSession session) {
        //生成验证码
        String text = producer.createText();
        BufferedImage image = producer.createImage(text);

        //验证码字符串写入到session中.服务器将依托cookie 【key,value】value中存放的是当前生成的sessionid.
        //以后浏览器访问浏览器时，将会携带该cookie信息，使得多个浏览器请求中携带重要的信息【基于HTTP请求是无状态的，将验证字符串存入到session中，保存到服务中】
        session.setAttribute("code", text);

        //图片响应给response
        //响应格式为.png的图片
        response.setContentType("image/png");
        try {
            ServletOutputStream outputStream = response.getOutputStream();
            //响应给浏览器的是验证码图片
            ImageIO.write(image,"png",outputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    /**
     * 用户登录
     * @return
     */
    @Override
    public Map<String, String> loginUser(LoginParam loginParam) {
        Map<String,String>map=new HashMap<>();
        //根据用户名去查询用户信息
        List<User> user = userMapper.selectList(new QueryWrapper<User>().eq("username", loginParam.getUsername()).ne("status",2));
        if(user==null||user.size()==0){
            map.put("usernameMsg","用户名账号错误！请重新输入");
        }else{
            //判断是否激活状态
            if(user.get(0).getStatus()==0){
                map.put("usernameMsg","账号未激活");
            }else{
                //校验密码
                if(!user.get(0).getPassword().equals(CommunityUtil.MD5str(user.get(0).getSalt() + loginParam.getPassword()))){
                    map.put("passwordMsg","密码错误");
                }
            }
        }

        if(map.isEmpty()){
            //插入登录凭证
            LoginTicket ticket=new LoginTicket();
            ticket.setTicket(CommunityUtil.generateUUID());
            ticket.setUserId(user.get(0).getId());
            ticket.setStatus(0);
            ticket.setCreateTime(new Date());
            //凭证超时时间 数字后加上L，避免因为Integer溢出导致时间数据计算错误
            Date time=loginParam.isRememberMe()?new Date(System.currentTimeMillis()+REMEMBER_EXPIRED_SECONDS*1000L)
                    :new Date(System.currentTimeMillis()+DEFAULT_EXPIRED_SECONDS*1000L);
            ticket.setExpired(time);
            ticketMapper.insert(ticket);
            map.put("ticket",ticket.getTicket());

        }

        return map;
    }

    @Override
    public Map<String, String> sendCodeEmail(String mail) {
        Map<String,String>map=new HashMap<>();
        //是否超过推送次数【5min中内次数不可超过3，否则算是重复推送】
        int i = verifyCodeMapper.selectVerifyCount(mail);
        if(i>=3){
            map.put("codeMsg","不要重复提交验证码申请");
            return map;
        }

        //发送验证码通知邮件
        MailBody mailBody=new MailBody();
        mailBody.setMailFrom(mailFrom);
        mailBody.setMailTo(mail);
        mailBody.setMailSubject("重设密码的验证码");
        String mailContent="";
        Context context=new Context();
        context.setVariable("username",mail);
        String code=CommunityUtil.randomStr(5);
        context.setVariable("code",code);
        mailContent=engine.process("/mail/forget",context);
        //mailUtil.sendMail(mailBody);

        //插入验证码数据
        VerifyCode verifyCode=new VerifyCode();
        verifyCode.setEmail(mail);
        verifyCode.setType("reset_password");
        verifyCode.setCode(code);
        verifyCode.setSendTime(new Date());
        verifyCode.setExpiredTime(new Date(System.currentTimeMillis()+VERIFY_CODE_EXPIRED_SECONDS*1000L));
        verifyCodeMapper.insert(verifyCode);
        return map;
    }


}
