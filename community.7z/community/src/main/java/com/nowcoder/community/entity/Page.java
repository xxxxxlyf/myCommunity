package com.nowcoder.community.entity;

import lombok.Data;

/**
 * @Author lyf
 * @Date 2023/3/4 - 17:50
 * @Description 封装分页信息
 **/
@Data
public class Page {

    /**
     * 分页总数
     */
    private  int rows;
    /**
     * 总页码
     */
    private  int total;
    /**
     * 当前页码
     */
    private int current;
    /**
     * 分页查询路径
     */
    private String path;
    /**
     * 分页显示数量
     */
    private int limit;

    private int from;
    private int to;


    /**
     * 获得分页偏移量
     * @return
     */
    public int getOffset(){
        return (current-1)*limit;
    }

    /**
     * 获得分页总页码,
     * @return
     */
    public int getTotal(){
        if(rows%limit==0){
            return rows/limit;
        }else{
            return rows/limit+1;
        }
    }


    /**
     * 获得起始页
     * @return
     */
    public int getFrom(){
        return current-2>0?current-2:1;
    }

    /**
     * 获得终止页
     * @return
     */
    public int getTo(){
      return current+3<getTotal()?current+3:getTotal();
    }

}
