package com.nowcoder.community.entity;

import lombok.Data;

/**
 * @Author lyf
 * @Date 2023/3/2 - 10:16
 * @Description
 **/
@Data
public class ReturnMessage <T>{

    private String mag;
    private T data;
    private Integer code;
}
