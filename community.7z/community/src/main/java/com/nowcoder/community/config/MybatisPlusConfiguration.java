package com.nowcoder.community.config;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;

/**
 * @Author lyf
 * @Date 2023/3/2 - 09:54
 * @Description
 **/
@MapperScan("com.nowcoder.community.dao")
@Configuration
public class MybatisPlusConfiguration {

}
