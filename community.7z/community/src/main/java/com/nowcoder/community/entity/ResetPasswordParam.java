package com.nowcoder.community.entity;

import lombok.Data;

/**
 * @Author lyf
 * @Date 2023/3/15 - 14:22
 * @Description 重设密码的参数类
 **/
@Data
public class ResetPasswordParam {

    private String code;
    private String email;
    private String password;
}
