package com.nowcoder.community.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.nowcoder.community.dao.DiscussPostMapper;
import com.nowcoder.community.dao.UserMapper;
import com.nowcoder.community.entity.DiscussPost;
import com.nowcoder.community.entity.Page;
import com.nowcoder.community.entity.User;
import com.nowcoder.community.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author lyf
 * @Date 2023/3/4 - 16:24
 * @Description
 **/
@Service
public class PostServiceImpl extends ServiceImpl<DiscussPostMapper,DiscussPost> implements PostService {

    @Autowired
    private UserMapper mapper;

    /**
     * 分页查询帖子详情
     * @param page 页码
     * @param limit 每页显示详情
     * @return
     */
    public Map<String,Object> selectPostByPage(int page,int limit){
       Map<String,Object>map=new HashMap<>();
        //查询帖子总数
        int total=this.baseMapper.selectPostCount(0);
        if(total>0){
            //查询帖子
            List<DiscussPost> postList = this.baseMapper.selectPostsByPage(0, (page - 1) * limit, limit);
            List<Map<String,Object>> discussPosts=new ArrayList();
            //遍历帖子查询用户详情
            for (DiscussPost post :postList){
                Map<String,Object> postInfo=new HashMap<>();
                postInfo.put("post",post);
                //根据用户id查询用户详情
                User user=mapper.selectUserById(post.getUserId());
                postInfo.put("user",user);
                discussPosts.add(postInfo);
            }
            map.put("discussPosts",discussPosts);

            //设置分页信息
            Page postPage=new Page();
            postPage.setRows(total);
            postPage.setCurrent(page);
            postPage.setLimit(10);
            postPage.setPath("/page");
            map.put("page",postPage);
        }

        return map;
    }
}
