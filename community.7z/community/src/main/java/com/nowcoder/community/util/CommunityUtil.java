package com.nowcoder.community.util;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.tomcat.util.security.MD5Encoder;
import org.springframework.util.DigestUtils;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * @Author lyf
 * @Date 2023/3/13 - 15:58
 * @Description
 **/
public class CommunityUtil {

    /**
     * 生成UUID随机字符串
     *
     * @return
     */
    public static String generateUUID() {
        return UUID.randomUUID().toString().replace("-", "").toString();
    }


    /**
     * MD5加密
     * @param str
     * @return
     */
    public static String MD5str(String str) {
        if(StringUtils.isEmpty(str)){
            return null;
        }
        return DigestUtils.md5DigestAsHex(str.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * 生成指定长度的随机字符串
     *
     * @param length
     * @return
     */
    public static String randomStr(int length) {
        char[] chars = new char[]{'0','1','2','3','4','5','6','7','8','9','0','a','b','c','d','e','f','g','h','i','j','k','l'};
        return RandomStringUtils.random(length,chars);
    }
}
