package com.nowcoder.community.service;


import java.util.Map;

/**
 * @Author lyf
 * @Date 2023/3/3 - 14:59
 * @Description
 **/
public interface PostService {

    /**
     * 分页查询帖子详情
     * @param page 页码
     * @param limit 每页显示详情
     * @return
     */
    Map<String,Object> selectPostByPage(int page,int limit);
}
