package com.nowcoder.community.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.nowcoder.community.entity.VerifyCode;
import org.springframework.stereotype.Repository;

@Repository
public interface VerifyCodeMapper extends BaseMapper<VerifyCode> {

    int selectVerifyCount(String email);
}
