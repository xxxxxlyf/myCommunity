//刷新验证码
function refresh_kaptcha() {
    var path = "/community/generateCode?p=" + Math.random();
    $("#kaptcha").attr("src", path);
}
