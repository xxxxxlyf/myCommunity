//获得验证码
function getVerifyCode() {
    var httpRequest = new XMLHttpRequest();//第一步：建立所需的对象
    //获得参数
    var email= $("#your-email").val();
    if(email==''||email==null||email==undefined){
        window.alert("邮箱不能为空")
    }else{
        var url = "/community/getVerifyCode/"+email;
        httpRequest.open('GET', url, true);//第二步：打开连接
        httpRequest.send();//第三步：发送请求
    }
}
